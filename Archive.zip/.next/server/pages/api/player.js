"use strict";
(() => {
var exports = {};
exports.id = 688;
exports.ids = [688];
exports.modules = {

/***/ 4210:
/***/ ((module) => {

module.exports = require("nedb");

/***/ }),

/***/ 4839:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ handler)
/* harmony export */ });
/* harmony import */ var nedb__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(4210);
/* harmony import */ var nedb__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(nedb__WEBPACK_IMPORTED_MODULE_0__);

const db = new (nedb__WEBPACK_IMPORTED_MODULE_0___default())({
    filename: "./db/player.db",
    autoload: true
});
db.loadDatabase();
function handler(req, res) {
    if (req.method === "POST") {
        if (req.body.player != null) {
            db.insert({
                name: req.body.player
            }, function(err, docs) {
                if (err) {
                    res.status(500).json(err);
                } else {
                    res.status(200).json({
                        message: "user added successfully!"
                    });
                }
            });
        } else {
            res.status(400).json({
                message: "Bad Request!"
            });
        }
    } else if (req.method === "DELETE") {
        if (!req.query.type) {
            res.status(400).json({
                message: "Bad Request!"
            });
        } else {
            if (req.query.type === "SINGLE") {
                if (!req.query.id) {
                    res.status(400).json({
                        message: "Bad Request!"
                    });
                } else {
                    db.remove({
                        _id: req.query.id
                    }, {
                        multi: false
                    }, function(err, docs) {
                        if (err) {
                            res.status(500).json(err);
                        } else {
                            res.status(200).json({
                                message: "Player deleted successfully"
                            });
                        }
                    });
                }
            } else if (req.query.type === "RESET") {
                db.remove({}, {
                    multi: true
                }, function(err, docs) {
                    if (err) {
                        res.status(500).json(err);
                    } else {
                        res.status(200).json({
                            message: "Player successfully being reset!"
                        });
                    }
                });
            } else {
                res.status(400).json({
                    message: "Bad Request!"
                });
            }
        }
    } else {
        db.find({
            name: {
                $exists: true
            }
        }, function(err, docs) {
            if (err) {
                res.status(500).json(err);
            } else {
                res.status(200).json(docs);
            }
        });
    }
}


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(4839));
module.exports = __webpack_exports__;

})();