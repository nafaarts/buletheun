"use strict";
(() => {
var exports = {};
exports.id = 578;
exports.ids = [578];
exports.modules = {

/***/ 4210:
/***/ ((module) => {

module.exports = require("nedb");

/***/ }),

/***/ 6344:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ handler)
/* harmony export */ });
/* harmony import */ var nedb__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(4210);
/* harmony import */ var nedb__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(nedb__WEBPACK_IMPORTED_MODULE_0__);

const db = new (nedb__WEBPACK_IMPORTED_MODULE_0___default())({
    filename: "./db/setting.db",
    autoload: true
});
db.loadDatabase();
const setup = ()=>{
    db.insert({
        location: "SR Badminton 3",
        address: "Cot Masjid, Lueng Bata",
        map_link: "https://n.nafaarts.com",
        total_hour: 2,
        price: 100000
    }, function(err, numReplaced) {
        res.status(200).json({
            message: "Setting added!"
        });
    });
};
function handler(req, res1) {
    if (req.method === "PUT") {
        if (req.query.id) {
            db.update({
                _id: req.query.id
            }, {
                $set: req.body
            }, function(err, numReplaced) {
                res1.status(200).json({
                    message: "Setting updated!"
                });
            });
        } else {
            res1.status(400).json({
                message: "bad Request"
            });
        }
    } else {
        db.find({}, function(err, docs) {
            if (docs.length === 0) {
                db.insert({
                    location: "SR Badminton",
                    address: "Cot Masjid, Lueng Bata",
                    map_link: "https://n.nafaarts.com",
                    total_hour: 2,
                    price: 100000
                }, function(err, numReplaced) {
                    db.find({}, function(err, docs) {
                        res1.status(200).json(docs[0]);
                    });
                });
            } else {
                res1.status(200).json(docs[0]);
            }
        });
    }
}


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(6344));
module.exports = __webpack_exports__;

})();